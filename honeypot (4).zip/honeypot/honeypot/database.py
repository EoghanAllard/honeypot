import mysql.connector

db_config = {
    'user': 'admin',
    'password': 'QwErtY23.',
    'host': 'honeypotdb.cbuakqw8o5hc.eu-north-1.rds.amazonaws.com',
    'database': 'test'
}
# db_config = {
#     'user': 'root',
#     'password': '',
#     'host': 'localhost',
#     'database': 'test'
# }

def get_connection():
    return mysql.connector.connect(**db_config)

def setup_database():
    cnx = get_connection()
    cursor = cnx.cursor()
    
    cursor.execute("CREATE DATABASE IF NOT EXISTS test")
    cursor.execute("USE test")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS honeypot_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            ip VARCHAR(255),
            route VARCHAR(255),
            method VARCHAR(10),
            user_agent TEXT,
            type_of_attack VARCHAR(255),
            additional_info TEXT
        )
    """)

    cursor.close()
    cnx.close()

# CRUD operations

# Create 
def create_log_entry(ip, route, method, user_agent, type_of_attack, additional_info):
    cnx = get_connection()
    cursor = cnx.cursor()
    add_log = ("INSERT INTO honeypot_logs "
               "(ip, route, method, user_agent, type_of_attack, additional_info) "
               "VALUES (%s, %s, %s, %s, %s, %s)")
    log_data = (ip, route, method, user_agent, type_of_attack, additional_info)
    cursor.execute(add_log, log_data)
    cnx.commit()
    cursor.close()
    cnx.close()

# Read 
def get_log_entries():
    cnx = get_connection()
    cursor = cnx.cursor(dictionary=True)
    query = ("SELECT * FROM honeypot_logs")
    cursor.execute(query)
    entries = cursor.fetchall()
    cursor.close()
    cnx.close()
    return entries

def get_log_entries_paginated(page, per_page=30):
    offset = (page - 1) * per_page
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor(dictionary=True)
    query = "SELECT SQL_CALC_FOUND_ROWS * FROM honeypot_logs LIMIT %s OFFSET %s"
    cursor.execute(query, (per_page, offset))
    logs = cursor.fetchall()
    cursor.execute("SELECT FOUND_ROWS()")
    total_rows = cursor.fetchone()['FOUND_ROWS()']
    cursor.close()
    cnx.close()
    return logs, total_rows

# Update 
def update_log_entry(log_id, type_of_attack):
    cnx = get_connection()
    cursor = cnx.cursor()
    update_log = ("UPDATE honeypot_logs "
                  "SET type_of_attack = %s "
                  "WHERE id = %s")
    cursor.execute(update_log, (type_of_attack, log_id))
    cnx.commit()
    cursor.close()
    cnx.close()

# Delete 
def delete_log_entry(log_id):
    cnx = get_connection()
    cursor = cnx.cursor()
    delete_log = ("DELETE FROM honeypot_logs WHERE id = %s")
    cursor.execute(delete_log, (log_id,))
    cnx.commit()
    cursor.close()
    cnx.close()

if __name__ == "__main__":
    setup_database()



