from flask import Flask, render_template, send_from_directory, request, redirect, url_for, flash, session, current_app
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database
from reporting_module.generate_report import generate_report, generate_attack_count_report, generate_ip_attack_type_report
import mysql.connector
from functools import wraps
from responseSystem.manual import block_ip,unblock_ip

app = Flask(__name__, template_folder='templates', static_folder='static')

app.secret_key = 'secret_key'

def is_authenticated():
    return 'username' in session

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not is_authenticated():
            flash('You need to be logged in to view this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def requires_roles(*roles):
    def wrapper(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if 'role' not in session or session['role'] not in roles:
                flash('You do not have the required permissions to view this page.', 'error')
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return wrapped
    return wrapper


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cnx = mysql.connector.connect(user='admin', password='QwErtY23.', host='honeypotdb.cbuakqw8o5hc.eu-north-1.rds.amazonaws.com', database='test')
        #cnx = mysql.connector.connect(user='root', password='', host='localhost', database='test')

        cursor = cnx.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        cursor.close()
        cnx.close()
        
        if user and user['password'] == password:  
            session['username'] = user['username']
            session['role'] = user['role']  
            return redirect(url_for('main_dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('username', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route('/')
def main_dashboard():
    if not is_authenticated():
        return redirect(url_for('login'))
    return render_template('main_dashboard.html')


#------------------------------------------ Ban IP ------------------------------------------

@app.route('/ban-management', methods=['GET', 'POST'])
@requires_auth
@requires_roles('admin')
def ban_management():
    if not is_authenticated():
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        ip_to_ban = request.form.get('ip_to_ban','').strip()
        action = request.form.get('action')
        print(f"Action: {action}, IP: {ip_to_ban}")

        try:
            if action == 'ban':
                print(f"Blocking IP Address: '{ip_to_ban}'")  
                result = block_ip(ip_to_ban)
                print(f"Blocking IP Address AFTER: '{ip_to_ban}'")
                if result.returncode == 0:
                    flash(f"IP address {ip_to_ban} has been blocked.")
                else:
                    flash(f"Failed to block IP address {ip_to_ban}: {result.stderr}")
            elif action == 'unban':
                result = unblock_ip(ip_to_ban)
                if result.returncode == 0:
                    flash(f"IP address {ip_to_ban} has been unblocked.") 
                else:
                    flash(f"Failed to unblock IP address {ip_to_ban}: {result.stderr}")
        except Exception as e:
            flash(str(e), 'error')

        return redirect(url_for('ban_management'))

    banned_ips = []
    return render_template('ban_management.html', banned_ips=banned_ips)





#------------------------------Database ------------------------------------------

@app.route('/database-crud', methods=['GET', 'POST'])
@requires_auth
def database_crud():
    page = request.args.get('page', 1, type=int)
    logs, total_rows = database.get_log_entries_paginated(page)
    total_pages = (total_rows + 29) // 30 
    return render_template('database_crud.html', logs=logs, page=page, total_pages=total_pages)

@app.route('/create-log', methods=['POST'])
@requires_auth
@requires_roles('admin')
def create_log():
    database.create_log_entry(
        request.form['ip'],
        request.form['route'],
        request.form['method'],
        request.form['user_agent'],
        request.form['type_of_attack'],
        request.form.get('additional_info')  
    )
    return redirect(url_for('database_crud'))

@app.route('/update-log/<int:log_id>', methods=['POST'])
@requires_auth
@requires_roles('admin')
def update_log(log_id):
    database.update_log_entry(
        log_id,
        request.form['type_of_attack']
    )
    return redirect(url_for('database_crud'))

@app.route('/delete-log/<int:log_id>', methods=['POST'])
@requires_auth
@requires_roles('admin')
def delete_log(log_id):
    database.delete_log_entry(log_id)
    return redirect(url_for('database_crud'))


#--------------------------------------- Report generator----------------------------------

@app.route('/report-generator', methods=['GET', 'POST'])
@requires_auth
def report_generator():
    if request.method == 'POST':
        report_type = request.form.get('report_type')
        if report_type == 'attack':
            report_filename = generate_report()
        elif report_type == 'ip_attack_type':
            report_filename = generate_ip_attack_type_report()
        elif report_type == 'attack_count':
            report_filename = generate_attack_count_report()
        else:
            flash('Invalid report type selected', 'error')
            return redirect(url_for('report_generator'))
        return redirect(url_for('download_report', filename=report_filename))
    return render_template('report_generator.html')

@app.route('/download-report/<filename>', methods=['GET'])
@requires_auth
@requires_roles('admin')
def download_report(filename):
    reports_directory = os.path.join(current_app.root_path,'reporting_module', 'reports')
    return send_from_directory(reports_directory, filename, as_attachment=True)


if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
