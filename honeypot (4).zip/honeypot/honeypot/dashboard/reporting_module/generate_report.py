import mysql.connector
from jinja2 import Environment, FileSystemLoader
import os
from datetime import datetime
import plotly.express as px
import pandas as pd

# db_config = {
#     'user': 'admin',
#     'password': 'QwErtY23.',
#     'host': 'honeypotdb.cbuakqw8o5hc.eu-north-1.rds.amazonaws.com',
#     'database': 'test'
# }
db_config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'test'
}

def get_attack_logs():
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor(dictionary=True)
    query = "SELECT * FROM honeypot_logs WHERE type_of_attack IS NOT NULL"
    cursor.execute(query)
    logs = cursor.fetchall()
    cursor.close()
    cnx.close()
    return logs

def save_and_render_report(template_filename, context):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    file_loader = FileSystemLoader(os.path.join(base_dir, 'templates'))
    env = Environment(loader=file_loader)
    template = env.get_template(template_filename)
    
    report_date = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    report_filename = f"{template_filename[:-5]}_{report_date}.html"
    report_filepath = os.path.join(base_dir, 'reports', report_filename)

    if not os.path.exists(os.path.join(base_dir, 'reports')):
        os.makedirs(os.path.join(base_dir, 'reports'))

    with open(report_filepath, 'w') as f:
        f.write(template.render(**context))

    print('Report generated successfully:', report_filename)
    return report_filename


def generate_report():
    logs = get_attack_logs()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    file_loader = FileSystemLoader(os.path.join(base_dir, 'templates'))
    env = Environment(loader=file_loader)
    template = env.get_template('attack_report.html')
    
    report_date = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')  
    report_filename = f"attack_report_{report_date}.html"
    report_filepath = os.path.join(base_dir, 'reports', report_filename)  
    report = template.render(logs=logs, report_date=report_date.replace('_', ':'))  

    if not os.path.exists(os.path.join(base_dir, 'reports')):
        os.makedirs(os.path.join(base_dir, 'reports'))

    with open(report_filepath, 'w') as f:
        f.write(report)

    print('Report generated successfully.')
    return report_filename 

def generate_ip_attack_type_report():
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor(dictionary=True)
    query = """
    SELECT ip, type_of_attack, COUNT(*) as count
    FROM honeypot_logs
    GROUP BY ip, type_of_attack
    ORDER BY ip, count DESC;
    """
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    cnx.close()

    logs_by_ip = {}
    for row in results:
            if row['ip'] not in logs_by_ip:
                logs_by_ip[row['ip']] = []
            logs_by_ip[row['ip']].append({'attack_type': row['type_of_attack'], 'count': row['count']})
            
    plot_html = ""
    for key, group in pd.DataFrame(results).groupby('ip'):
        fig = px.bar(group, x='type_of_attack', y='count', title=f'Attacks for IP {key}')
        fig.update_layout(xaxis_title='Type of Attack', yaxis_title='Count')
        plot_html += fig.to_html(full_html=False, include_plotlyjs='cdn')

    return save_and_render_report('ip_attack_type_report.html', {'plot_div': plot_html, 'logs_by_ip': logs_by_ip})

def generate_attack_count_report():
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor(dictionary=True)
    query = "SELECT type_of_attack, COUNT(*) as count FROM honeypot_logs GROUP BY type_of_attack ORDER BY count DESC;"
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    cnx.close()

    df = pd.DataFrame(results)

    fig = px.bar(df, x='type_of_attack', y='count', title='Count of Each Attack Type')
    fig.update_layout(xaxis_title='Type of Attack', yaxis_title='Count')

    plot_html = fig.to_html(full_html=False, include_plotlyjs='cdn')

    return save_and_render_report('attack_count_report.html', {'plot_div': plot_html, 'attacks': results})


if __name__ == '__main__':
    generate_ip_attack_type_report()
    generate_attack_count_report()