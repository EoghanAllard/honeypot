import subprocess

def update_firewall_rules(ip_address, action='block'):
    """
    Update Windows Defender Firewall rules to block or unblock an IP address.
    """
    if action == 'block':
        command = f"New-NetFirewallRule -DisplayName 'Block {ip_address}' -Direction Inbound -Action Block -RemoteAddress {ip_address}"
        
    elif action == 'unblock':
        command = f"Remove-NetFirewallRule -DisplayName 'Block {ip_address}'"
    else:
        raise ValueError("Invalid action specified for update_firewall_rules")

    try:
        subprocess.run(["powershell", "-Command", command], check=True)
        return True
    except subprocess.CalledProcessError as e:
        return False

if __name__ == "__main__":
    # Test
    success = update_firewall_rules('192.168.1.100', action='block')
    print("Blocking IP succeeded:", success)
