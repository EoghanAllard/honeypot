import subprocess
import click

def run_powershell(command):
    """ Helper function to run PowerShell commands """
    result = subprocess.run(["powershell", "-Command", command], capture_output=True)
    return result

@click.group()
def cli():
    """Honeypot Manual Intervention Tool"""
    pass

@cli.command()
@click.argument('ip_address')
def block_ip(ip_address):
    """Block the given IP address by updating the firewall rules."""
    command = f"New-NetFirewallRule -DisplayName 'Block {ip_address}' -Direction Inbound -Action Block -RemoteAddress {ip_address}"
    print(f"Blocking IP Address AFTER CMD: '{ip_address}'")  # Debug output

    result = subprocess.run(["powershell", "-Command", command], capture_output=True, text=True)
    print(f"Blocking IP Address AFTER RESULT: '{ip_address}'")  # Debug output

    if result.returncode == 0:
        click.echo(f"IP address {ip_address} has been blocked.")
    else:
        click.echo(f"Failed to block IP address {ip_address}: {result.stderr}")

@cli.command()
@click.argument('ip_address')
def unblock_ip(ip_address):
    """Unblock the given IP address by removing the firewall rule."""
    command = f"Remove-NetFirewallRule -DisplayName 'Block {ip_address}'"
    result = subprocess.run(["powershell", "-Command", command], capture_output=True, text=True)
    if result.returncode == 0:
        click.echo(f"IP address {ip_address} has been unblocked.")
    else:
        click.echo(f"Failed to unblock IP address {ip_address}: {result.stderr}")

if __name__ == '__main__':
    cli()
