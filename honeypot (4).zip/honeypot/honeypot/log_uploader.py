import boto3
from datetime import datetime

def upload_log_to_s3(file_path, bucket_name):
    s3_client = boto3.client('s3')
    file_name = datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + "_honeypot_log.txt"
    s3_client.upload_file(file_path, bucket_name, file_name)
    print(f"Uploaded {file_name} to {bucket_name}")

if __name__ == '__main__':
    log_file_path = '/path/to/honeypot/logs/honeypot_interactions.log'
    s3_bucket_name = 'your-s3-bucket-name'
    upload_log_to_s3(log_file_path, s3_bucket_name)
