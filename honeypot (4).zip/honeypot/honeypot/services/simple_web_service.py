from flask import Flask, request, send_from_directory, render_template, jsonify, render_template_string
import logging
from logging.handlers import RotatingFileHandler
import json
import datetime
import os
import mysql.connector

app = Flask(__name__)

handler = RotatingFileHandler('honeypot.log', maxBytes=500*100, backupCount=5)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(handler)

def log_request(req, attack_type, form_data=None):
    db_config = {
        'user': 'admin',
        'password': 'QwErtY23.',
        'host': 'honeypotdb.cbuakqw8o5hc.eu-north-1.rds.amazonaws.com',
        'database': 'test'
    }
    # db_config = {
    #     'user': 'root',
    #     'password': '',
    #     'host': 'localhost',
    #     'database': 'test'
    # }
    cnx = mysql.connector.connect(**db_config)
    cursor = cnx.cursor()

    form_data_str = json.dumps(form_data) if form_data else ""

    add_log = ("INSERT INTO honeypot_logs "
               "(ip, route, method, user_agent, type_of_attack, additional_info) "
               "VALUES (%s, %s, %s, %s, %s, %s)")

    log_data = (req.headers.get('X-Forwarded-For', req.remote_addr),
                req.path,
                req.method,
                str(req.user_agent),
                attack_type,
                form_data_str)

    cursor.execute(add_log, log_data)
    cnx.commit()
    cursor.close()
    cnx.close()

@app.route('/')
def home():
    log_request(request, "General Page Visit")
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form.get('user')
        password = request.form.get('password')
        form_data = {"user": user, "password": password}
        attack_type = "Brute Force or Credential Stuffing"
        log_request(request, attack_type, form_data=form_data)
        message = "Login attempt recorded."
    else:
        attack_type = "Login Page Visit"
        log_request(request, attack_type)
        message = None
    return render_template('login.html', message=message)

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        form_data = {"username": username, "password": password}
        attack_type = "Admin Console Credential Attack"
        log_request(request, attack_type, form_data=form_data)
        message = "Admin login attempt logged."
    else:
        attack_type = "Admin Console Page Visit"
        log_request(request, attack_type)
        message = None
    return render_template('admin_login.html', message=message)

@app.route('/data/fake_credit_cards.json')
def serve_json():
    directory = os.path.join(app.root_path, 'data')
    return send_from_directory(directory, 'fake_credit_cards.json')

@app.route('/data')
def data():
    log_request(request, "Unauthorized Data Access Attempt")
    return render_template('data.html')

def load_json_data():
    directory = os.path.join(app.root_path, 'data', 'fake_users.json')
    with open(directory, 'r') as file:
        return json.load(file)

@app.route('/api/data')
def api_data():
    log_request(request, "Automated Script or Bot Data Scraping")
    data = load_json_data() 
    return jsonify(data)


@app.route('/search')
def search():
    query = request.args.get('q', '')
    attack_type = "Potential SQL Injection or XSS via Search Query"
    log_request(request, attack_type, form_data={"query": query})
    search_response = f"<h2>Search Results for '{query}'</h2><p>No results found. This is a simulated response.</p>"
    return render_template_string(search_response)

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files.get('file')
        if file:
            file_info = {"filename": file.filename, "content_type": file.content_type}
            attack_type = "Malicious File Upload Attempt"
            log_request(request, attack_type, form_data=file_info)
            message = "File upload simulated."
        else:
            message = "No file selected."
        log_request(request, attack_type, form_data={"message": message})
    else:
        attack_type = "File Upload Page Visit"
        log_request(request, attack_type)
        message = None
    return render_template('upload.html', message=message)



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
