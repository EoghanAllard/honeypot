import random
import json

first_names = ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda",
               "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
               "Thomas", "Sarah", "Charles", "Karen", "Christopher", "Nancy", "Daniel", "Lisa",
               "Matthew", "Margaret", "Anthony", "Betty", "Mark", "Sandra", "Donald", "Ashley",
               "Steven", "Dorothy", "Paul", "Kimberly", "Andrew", "Emily", "Joshua", "Donna",
               "Kenneth", "Michelle", "Kevin", "Carol", "Brian", "Amanda", "George", "Melissa",
               "Edward", "Deborah", "Ronald", "Stephanie", "Timothy", "Rebecca", "Jason", "Laura",
               "Jeffrey", "Helen", "Ryan", "Sharon", "Jacob", "Cynthia", "Gary", "Kathleen",
               "Nicholas", "Amy", "Eric", "Shirley", "Stephen", "Angela", "Jonathan", "Anna",
               "Larry", "Ruth", "Justin", "Brenda", "Scott", "Pamela", "Brandon", "Nicole",
               "Frank", "Katherine", "Benjamin", "Samantha", "Gregory", "Christine", "Raymond", "Catherine",
               "Samuel", "Virginia", "Patrick", "Debra", "Alexander", "Rachel", "Jack", "Janet",
               "Dennis", "Emma", "Jerry", "Carolyn"]

last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson",
              "Moore", "Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin",
              "Thompson", "Garcia", "Martinez", "Robinson", "Clark", "Rodriguez", "Lewis", "Lee",
              "Walker", "Hall", "Allen", "Young", "Hernandez", "King", "Wright", "Lopez", "Hill",
              "Scott", "Green", "Adams", "Baker", "Gonzalez", "Nelson", "Carter", "Mitchell",
              "Perez", "Roberts", "Turner", "Phillips", "Campbell", "Parker", "Evans", "Edwards",
              "Collins", "Stewart", "Sanchez", "Morris", "Rogers", "Reed", "Cook", "Morgan",
              "Bell", "Murphy", "Bailey", "Rivera", "Cooper", "Richardson", "Cox", "Howard",
              "Ward", "Torres", "Peterson", "Gray", "Ramirez", "James", "Watson", "Brooks",
              "Kelly", "Sanders", "Price", "Bennett", "Wood", "Barnes", "Ross", "Henderson",
              "Coleman", "Jenkins", "Perry", "Powell", "Long", "Patterson", "Hughes", "Flores",
              "Washington", "Butler", "Simmons", "Foster", "Gonzales", "Bryant", "Alexander", "Russell"]

domain_names = ["gmail.com", "hotmail.com", "yahoo.com", "outlook.com", "example.com"]

addresses = [
    "123 Elm St, Springfield, IL",
    "456 Oak St, Anytown, CA",
    "789 Maple Ave, Smallville, TX",
    "101 Pine Rd, Centerville, MA",
    "202 Birch Blvd, Lake City, FL",
    "303 Cedar Ln, Hill Valley, NV",
    "404 Dogwood Dr, Metro City, GA",
    "505 Fir Ct, Gotham, NY",
    "606 Elm St, Springfield, IL",
    "707 Oak St, Anytown, CA",
    "808 Maple Ave, Smallville, TX",
    "909 Pine Rd, Centerville, MA",
    "124 Elm St, Springfield, IL",
    "452 Oak St, Anytown, CA",
    "784 Maple Ave, Smallville, TX",
    "107 Pine Rd, Centerville, MA",
    "206 Birch Blvd, Lake City, FL",
    "307 Cedar Ln, Hill Valley, NV",
    "408 Dogwood Dr, Metro City, GA",
    "504 Fir Ct, Gotham, NY",
    "603 Elm St, Springfield, IL",
    "709 Oak St, Anytown, CA",
    "803 Maple Ave, Smallville, TX",
    "904 Pine Rd, Centerville, MA"
]

names = set()
while len(names) < 1001:
    first_name = random.choice(first_names)
    last_name = random.choice(last_names)
    name = f"{first_name} {last_name}"
    names.add(name)

users = []
for idx, name in enumerate(names, 1):
    first, last = name.split()
    domain = random.choice(domain_names)
    email = f"{first.lower()}.{last.lower()}@{domain}"
    phone_number = f"{random.randint(100, 999)}-{random.randint(100, 999)}-{random.randint(1000, 9999)}"
    address = random.choice(addresses)
    users.append({
        "id": random.randint(100000, 999999), 
        "name": name,
        "email": email,
        "phone": phone_number,
        "address": address  
    })

json_data = {
    "users": users,
    "message": "This is fake data from a simulated API endpoint."
}

with open("fake_users.json", "w") as json_file:
    json.dump(json_data, json_file, indent=4)

json_data
