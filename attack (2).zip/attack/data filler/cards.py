import json
import random

from random import randint
from datetime import datetime, timedelta

first_names = ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda",
               "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
               "Thomas", "Sarah", "Charles", "Karen", "Christopher", "Nancy", "Daniel", "Lisa",
               "Matthew", "Margaret", "Anthony", "Betty", "Mark", "Sandra", "Donald", "Ashley",
               "Steven", "Dorothy", "Paul", "Kimberly", "Andrew", "Emily", "Joshua", "Donna",
               "Kenneth", "Michelle", "Kevin", "Carol", "Brian", "Amanda", "George", "Melissa",
               "Edward", "Deborah", "Ronald", "Stephanie", "Timothy", "Rebecca", "Jason", "Laura",
               "Jeffrey", "Helen", "Ryan", "Sharon", "Jacob", "Cynthia", "Gary", "Kathleen",
               "Nicholas", "Amy", "Eric", "Shirley", "Stephen", "Angela", "Jonathan", "Anna",
               "Larry", "Ruth", "Justin", "Brenda", "Scott", "Pamela", "Brandon", "Nicole",
               "Frank", "Katherine", "Benjamin", "Samantha", "Gregory", "Christine", "Raymond", "Catherine",
               "Samuel", "Virginia", "Patrick", "Debra", "Alexander", "Rachel", "Jack", "Janet",
               "Dennis", "Emma", "Jerry", "Carolyn"]

last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson",
              "Moore", "Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin",
              "Thompson", "Garcia", "Martinez", "Robinson", "Clark", "Rodriguez", "Lewis", "Lee",
              "Walker", "Hall", "Allen", "Young", "Hernandez", "King", "Wright", "Lopez", "Hill",
              "Scott", "Green", "Adams", "Baker", "Gonzalez", "Nelson", "Carter", "Mitchell",
              "Perez", "Roberts", "Turner", "Phillips", "Campbell", "Parker", "Evans", "Edwards",
              "Collins", "Stewart", "Sanchez", "Morris", "Rogers", "Reed", "Cook", "Morgan",
              "Bell", "Murphy", "Bailey", "Rivera", "Cooper", "Richardson", "Cox", "Howard",
              "Ward", "Torres", "Peterson", "Gray", "Ramirez", "James", "Watson", "Brooks",
              "Kelly", "Sanders", "Price", "Bennett", "Wood", "Barnes", "Ross", "Henderson",
              "Coleman", "Jenkins", "Perry", "Powell", "Long", "Patterson", "Hughes", "Flores",
              "Washington", "Butler", "Simmons", "Foster", "Gonzales", "Bryant", "Alexander", "Russell"]

names = set()
while len(names) < 1000:
    first_name = random.choice(first_names)
    last_name = random.choice(last_names)
    name = f"{first_name} {last_name}"
    names.add(name)

# Convert the set to a list to ensure stable order for iteration
names = list(names)

def generate_card_number():
    """Generates a random credit card number in the 16-digit format commonly used."""
    return ' '.join([''.join([str(randint(0, 9)) for _ in range(4)]) for _ in range(4)])

def generate_expiry_date():
    """Generates a random expiry date that is valid from today up to 5 years later."""
    current_year = datetime.now().year
    current_month = datetime.now().month
    expiry_year = randint(current_year, current_year + 5)
    expiry_month = randint(1, 12) if expiry_year > current_year else randint(current_month, 12)
    return f"{expiry_month:02}/{str(expiry_year)[-2:]}"

def generate_cvv():
    """Generates a random 3-digit card verification value (CVV)."""
    return ''.join([str(randint(0, 9)) for _ in range(3)])

# Generate fake credit card information for each name
fake_credit_cards = [{
    'Name': name,
    'Card Number': generate_card_number(),
    'Expiry Date': generate_expiry_date(),
    'CVV': generate_cvv()
} for name in names]

json_filename = 'fake_credit_cards.json'
with open(json_filename, 'w') as f:
    json.dump(fake_credit_cards, f, indent=4)

json_filename
