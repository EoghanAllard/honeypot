import json
import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

with open('credentials.json', 'r') as file:
    credentials = json.load(file)

def login_page():
    for user_credential in credentials['user_credentials']:
        driver.get('http://127.0.0.1:5000/login')
        time.sleep(2)
        user_input = driver.find_element(By.NAME, 'user')
        password_input = driver.find_element(By.NAME, 'password')
        user_input.clear()  
        password_input.clear()  
        user_input.send_keys(user_credential['username'])
        password_input.send_keys(user_credential['password'])
        password_input.send_keys(Keys.RETURN)
        time.sleep(2)  
        print(f"Visited login page and submitted credentials for {user_credential['username']}.")

def admin_login_page():
    for admin_credential in credentials['admin_credentials']:
        driver.get('http://127.0.0.1:5000/admin')
        time.sleep(2)
        username_input = driver.find_element(By.NAME, 'username')
        password_input = driver.find_element(By.NAME, 'password')
        username_input.clear()  
        password_input.clear()  
        username_input.send_keys(admin_credential['username'])
        password_input.send_keys(admin_credential['password'])
        password_input.send_keys(Keys.RETURN)
        time.sleep(2)  
        print(f"Visited admin login page and submitted credentials for {admin_credential['username']}.")

def data_page():
    driver.get('http://127.0.0.1:5000/data')
    time.sleep(2)
    print("Visited data page.")

def api_data_page():
    driver.get('http://127.0.0.1:5000/api/data')  
    time.sleep(2)
    print("API data fetched:", driver.find_element(By.TAG_NAME, "body").text)

def search_page():
    with open('sql_injection_queries.json', 'r') as file:
        data = json.load(file)
        queries = data["queries"]
    
    for query in queries:
        driver.get(f'http://127.0.0.1:5000/search?q={query}') 
        time.sleep(2)
        print(f"Performed search with query: {query}")

def upload_file_page():
    driver.get('http://127.0.0.1:5000/upload')  
    time.sleep(2)
    
    downloads_path = '\Downloads'  
    
    files = os.listdir(downloads_path)
    
    for file_name in files:
        full_path = os.path.join(downloads_path, file_name)
        
        file_input = driver.find_element(By.NAME, 'file')
        file_input.send_keys(full_path)
        time.sleep(1)  
        
        file_input.submit()
        time.sleep(2)  
        
        print(f"Uploaded file: {file_name}")

login_page()
admin_login_page()
data_page()
api_data_page()
search_page()
upload_file_page()

driver.quit()
